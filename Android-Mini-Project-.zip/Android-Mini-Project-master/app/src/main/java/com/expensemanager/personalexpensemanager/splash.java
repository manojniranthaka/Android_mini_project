package com.expensemanager.personalexpensemanager;

import android.os.Bundle;
import android.app.Activity;

public class splash extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
    }

}
