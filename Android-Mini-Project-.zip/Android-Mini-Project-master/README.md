# Android-Mini-Project
This project was made in 2nd Year 1st Semester. <br/>
In this project a Simple Daily Expense Tracker is made. <br/>
Expenses are categorized as Food, Transport, and Shopping expenses <br/>

Technologies used
* Android
* Android in built MySQL Lite Database

Members Involved
* Sathira
* Sahan Jayawardene 
* Sahan Illandara
* Manoj Niranthaka
